# Sales Game V2 — Sorte & Revés em Three.js

Base: `SALESGAME V2.zip`, pasta `SALESGAME V2/sales-game-/`. Entrega de 08/09/2026.

Implementação concluída na cópia do projeto. Validação automatizada aprovada. **Validação visual pendente; esta entrega não declara o projeto pronto para produção.**

## O que mudou

- Carta com geometria extrudada, bordas arredondadas, espessura, materiais metálicos e iluminação Three.js. Frente e verso distintos; identidade Sales Game, verde/dourado para SORTE e vermelho/cobre para REVÉS.
- Baralho decorativo no centro do tabuleiro, sem ocupar espaço no layout. Em repouso é CSS, sem WebGL ou loop permanente.
- Animação de 2.400 ms: saída de costas (500 ms), aproximação (700 ms), giro adicional de 540° (900 ms) e assentamento (300 ms). A orientação final é a frente.
- Transição de opacidade de 180 ms para conteúdo React nítido. Texturas geradas por Canvas 2D contêm apenas arte e identificação; título, descrição, valor e controles são DOM.
- Tocar/clicar ou usar Enter/Espaço no controle de revelação adianta apenas a animação. OK só fica disponível após a revelação, conforme a especificação mais recente. A trava de confirmação única permanece.
- Movimento reduzido evita criar o renderer. Falha do renderer, perda de contexto ou limite de espera levam à leitura da carta. Cleanup cancela RAF/timers/listeners, descarta recursos e libera o contexto WebGL.
- Os MP3s, o controlador de áudio, os volumes 0,80/0,35 e a preferência `sg:sorteRevesSound` permanecem intactos. O som acompanha a nova revelação ao fim do assentamento; confirmar corta o áudio pelo mesmo controlador.

## Arquitetura e adaptação ao V2

O `SorteRevesModal.jsx` continua sendo o dono do sorteio, de `resolveCardEffect(card, player)` e de `onResolve?.(resolved.payload)`. A cena recebe somente a variante e referências de posição; devolve um aviso de revelação, sem payload do jogo.

O monte em repouso foi inserido como irmão de Board em `.boardWrap`, com apenas uma importação e um elemento novo em `App.jsx`. Nenhuma lógica de App mudou.

**Adaptação em relação ao prompt antigo:** a cena animada permanece dentro do modal existente, sobre o backdrop translúcido do `ModalProvider`. Sua origem é calculada pelo centro do monte no tabuleiro; a leitura termina centralizada na tela. O canvas não foi portado para `.boardWrap`: isso evita alterar o empilhamento e o comportamento do modal existente no V2. Portanto, não se trata de uma reprodução literal do ponto de montagem do overlay do dado.

O monte de repouso é estático; não há flutuação contínua entre cartas. Em telas baixas, a superfície de leitura fica mais larga e o conteúdo interno pode rolar. A geometria acompanha as dimensões dessa superfície na transição. O acabamento dessa adaptação ainda exige observação em navegador.

## Escopo exato

Quatro arquivos preexistentes alterados:

| Arquivo | Alteração |
|---|---|
| `src/App.jsx` | Importação e montagem do monte decorativo; duas inserções |
| `src/modals/SorteRevesModal.jsx` | Composição da apresentação, revelação, foco e confirmação habilitada após revelar |
| `src/modals/__tests__/sorteReves3D.test.mjs` | Atualiza o contrato de disponibilidade de OK |
| `src/modals/__tests__/sorteRevesRevealSound.test.mjs` | Atualiza o mesmo contrato; mantém testes de áudio |

Seis arquivos novos:

- `src/modals/SorteRevesScene.jsx`
- `src/modals/sorteRevesScene.js`
- `src/modals/SorteRevesCardContent.jsx`
- `src/modals/sorte-reves.css`
- `src/modals/__tests__/sorteRevesScene.test.mjs`
- `src/modals/__tests__/fixtures/sorteRevesPayloads.json`

Foram comparados hashes SHA-256 com a base: **184 arquivos protegidos permaneceram idênticos**, incluindo arquivos do motor, baralhos, bots, tabuleiro, overlay do dado, controlador de som, oito mídias de Sorte & Revés, manifests de dependências e arquivos de `dist/` presentes na base.

Nenhuma dependência, configuração, regra, sorteio, payload, modalidade, preferência de IA ou remoção de troca de jogador foi alterada. Os componentes e arquivos antigos de vídeo permanecem no projeto, mas o modal deixa de usá-los. Não houve commit, push ou deploy.

## Evidências

| Verificação executada | Resultado |
|---|---|
| `npm test`, antes | 893 testes, zero falhas |
| `npm test`, depois | **906 testes, 213 suítes, zero falhas**, 19,07 s |
| `npm run test:check` | Sucesso; neste projeto verifica a presença de arquivos, não executa a suíte |
| `npm run build -- --outDir <diretório temporário>` | **Sucesso**, 13,11 s; `dist/` preservado |
| React SSR | 136 renderizações: 34 cartas × dois estados de jogador × antes/depois da revelação; descrição integral, inert e disponibilidade do botão verificadas |
| `git apply --check --whitespace=error-all` | Sucesso contra cópia dos arquivos do ZIP |
| Aplicação do patch | Dez arquivos iguais byte a byte à implementação validada |
| Reversão do patch | Arquivos originais restaurados byte a byte; novos arquivos removidos |

Os 13 testes novos cobrem orientação, continuidade das fases, revelação única, cancelamento, callback tardio, reinício de sessão, interrupção durante desenho, descarte de recursos Three, paridade humano/bot das 34 cartas, snapshot de payloads, constantes e restrições de CSS. O primeiro teste foi executado em vermelho antes do módulo existir; os dois casos adicionais de cancelamento também falharam antes da correção. Verificações de contratos por leitura do código são guardas estáticas, não prova de execução do componente no navegador.

O build emitiu avisos de chunk JavaScript acima de 500 kB e importação estática/dinâmica de `screenOrientation.js`. Não foi feito ajuste global de bundle neste escopo.

A cópia de trabalho foi extraída sem metadados Git. Não se executou `git restore -- dist` nem `git diff --check` nela: o build foi direcionado para fora, os hashes de dist foram preservados e o patch passou na checagem de whitespace acima.

## Limitações e bloqueio existente

O navegador desta sessão bloqueou a URL do servidor local com `ERR_BLOCKED_BY_CLIENT`. Não houve contorno desse bloqueio.

**Não foram produzidas as capturas solicitadas, nem observados o giro contínuo, a iluminação, a composição final, a audição dos MP3s ou o fluxo real do jogo desta implementação.** Os testes de SSR não medem tamanho, overflow, foco real, autoplay, StrictMode do navegador ou funcionamento em Safari/iOS/Firefox. Os relatos de navegador da implementação anterior não são evidência desta versão.

O relatório recebido descreve avanço de turno com carta ainda pendente e consequente perda de efeito. Esse problema **não foi corrigido nem reproduzido nesta etapa**. `useTurnEngine.jsx` permaneceu idêntico. Ele precisa de investigação separada antes de declarar o projeto encerrado.

## Aplicar no repositório local

O ZIP de entrega contém o patch, os dez arquivos finais em `arquivos/`, este relatório e `integridade.json` com hashes antes/depois. O patch foi criado contra o **conteúdo do V2 enviado**, incluindo suas alterações ainda não commitadas, não contra uma main antiga.

1. Extraia o pacote de entrega fora da pasta do projeto.
2. No terminal, entre na raiz do projeto que contém `package.json`.
3. Ajuste o caminho abaixo para o local onde extraiu o pacote e execute:

```bash
git apply --check "CAMINHO/sorte-reves-three.patch"
git apply "CAMINHO/sorte-reves-three.patch"
npm test
npm run build -- --outDir ../salesgame-build-validacao
git diff --check
```

Se `--check` falhar, não force nem substitua arquivos manualmente: existe diferença entre sua cópia e o V2 enviado. Compare os arquivos indicados e adapte somente os trechos da apresentação. A pasta `arquivos/` serve para revisão ou integração assistida; não substitua o projeto inteiro por ela.

Para reverter **somente este patch**, desde que não tenha feito alterações posteriores nesses trechos:

```bash
git apply --reverse --check "CAMINHO/sorte-reves-three.patch"
git apply --reverse "CAMINHO/sorte-reves-three.patch"
```

## Validação manual necessária

Execute `npm run dev` e abra o endereço exibido pelo Vite em uma aba visível.

- Inicie partida local e abra cartas de SORTE e REVÉS no fluxo real. Registre o jogador dono da carta e o caixa antes/depois para detectar o problema de turno já relatado.
- Nas resoluções 1920×1080, 844×390 e 394×858, confira repouso, aproximação, meio do giro e revelação. Registre vídeo/capturas; confirme que termina de frente e que o tabuleiro permanece visível.
- Confira descrição longa, rolagem por toque/teclado e botão OK alcançável. Verifique também zoom de texto.
- Clique durante o giro: deve revelar, sem aplicar efeito. Confirme depois: efeito uma única vez. Reabra outra carta e confira estado visual e áudio novos.
- Confira som ao revelar, corte ao confirmar/ocultar aba, controle de som, movimento reduzido e fallback sem WebGL.
- Confira pelo menos Chrome desktop, Firefox e Safari/iOS antes de aprovar a apresentação para todos os dispositivos.
