# Prompt de integração cirúrgica — somente Sorte & Revés

Integre os vídeos 3D de Sorte & Revés anexados ao Sales Game existente. O objetivo é exclusivamente melhorar a apresentação deste modal em React. A animação foi pré-renderizada no Blender e não requer Three.js adicional.

## Contexto confirmado no ZIP analisado

- O modal está em `src/modals/SorteRevesModal.jsx`.
- A seleção usa `useState(() => CARDS[Math.floor(Math.random() * CARDS.length)])`.
- `CARDS` referencia `SORTE_REVES_CARDS`, importado de `sorteRevesDeck.js`.
- `resolved` vem de `resolveCardEffect(card, player)` com `useMemo`.
- O callback de confirmação chama `onResolve?.(resolved.payload)`.
- `src/game/useTurnEngine.jsx` abre e aguarda esse modal.
- O modal não oferece X, cancelamento ou fechamento voluntário por Escape/backdrop. Preserve esse contrato.

Leia as instruções locais aplicáveis, inspecione o estado atual desses pontos e preserve alterações preexistentes do usuário. Se o projeto tiver evoluído desde o ZIP, use o código atual como referência, sem substituir arquivos inteiros pela versão antiga.

## Escopo permitido

1. Adicionar os seis arquivos de `media/` em `public/media/sorte-reves/`.
2. Ajustar apenas a apresentação e o estado visual local de `src/modals/SorteRevesModal.jsx`.
3. Criar, somente se necessário, um componente de mídia e estilos exclusivos desse modal, com nomes delimitados ao recurso.

Não altere o baralho, o motor de turno, o estado global, o reducer, Supabase, rede, economia, sorteio, probabilidades, valores ou condicionais. Não refatore outros modais, compras, multiplayer, espectador ou IA. Não atualize dependências e não faça migração de framework.

## Integração

- Escolha o nome da mídia exclusivamente a partir de `card.kind === 'SORTE' ? 'sorte' : 'reves'`. Não sorteie novamente e não remonte o modal para reiniciar a mídia.
- Use React e o player nativo, com `muted`, `playsInline`, `preload="metadata"`, sem `loop` e sem controles do player. O player é decorativo e não deve interceptar o botão de confirmação.
- Trate rejeição de `play()`, erro de carregamento e vídeo parado sem progresso: mostre o PNG final e mantenha a confirmação disponível. Uma falha de mídia nunca pode prender o turno.
- Ao receber `ended`, retenha o quadro final ou troque pelo PNG final. Essa operação altera somente o estado visual; não chama `resolve`, `onResolve`, `APPLY_CARD` ou qualquer ação de jogo.
- Se houver texto sobreposto à carta, apresente essa sobreposição quando a mídia atingir aproximadamente 1,47 s ou quando for substituída pelo PNG. Durante o giro, mantenha a confirmação acessível no painel do modal. Não use um cronômetro visual ou um atraso obrigatório para liberar a ação.
- Para `prefers-reduced-motion: reduce`, mostre diretamente o PNG. Limpe listeners, timers e a reprodução ao desmontar.
- O WebM tem alfa; o MP4 é opaco. Se o ambiente não compuser o alfa corretamente, escolha o MP4 sobre um painel `#07111F` ou o PNG. Não assuma que `canPlayType()` comprova suporte à transparência.
- Mantenha `card.title`, `resolved.text`, a informação de que o efeito será aplicado ao confirmar e o botão no React. Não invente saldos ou calcule o impacto financeiro no componente visual. Preserve também `TileContextHint`.
- A área gráfica final para conteúdo é `left:25.5%; top:47%; width:49%; height:31%` do quadro 4:5. Use sobreposição apenas quando houver espaço real. Em telas estreitas, fonte ampliada ou descrição longa, mostre o texto e a confirmação em painel fluido abaixo da mídia. Preserve legibilidade, rolagem e foco, sem cortar textos ou reduzir a fonte indiscriminadamente.
- A confirmação deve ser acessível sem esperar obrigatoriamente os 2,4 segundos. Se houver uma ação para abreviar a animação, ela apenas revela o conteúdo; não fecha o modal nem aplica o efeito.
- Preserve o `role="dialog"`, o nome acessível, a gestão de foco e o scroll lock existentes. O conteúdo real deve estar disponível para tecnologias assistivas independentemente da animação decorativa.
- Evite confirmações duplicadas: use uma trava local por abertura, sem mudar o payload ou introduzir estado de domínio. Somente a confirmação chama uma vez o callback existente com `resolved.payload`.

## Verificação restrita ao risco desta alteração

Execute os testes existentes de Sorte & Revés e o build do projeto. Não modifique testes do baralho para acomodar alterações de regra. Verifique no navegador uma carta de cada tipo, um efeito condicionado ao jogador, uma descrição longa, confirmação por teclado, clique duplo, fechamento após confirmação, movimento reduzido e falha da mídia. Confira pelo menos uma tela móvel e uma desktop.

Ao final, apresente o diff, os arquivos efetivamente alterados e as verificações executadas. Informe qualquer verificação bloqueada. Não faça commit, push ou deploy sem autorização. O resultado esperado é o mesmo efeito da mesma carta, aplicado pelo mesmo fluxo de confirmação, com uma apresentação 3D independente da lógica.
