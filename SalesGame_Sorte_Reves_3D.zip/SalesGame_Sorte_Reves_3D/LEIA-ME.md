# Sales Game — Sorte & Revés em 3D

Dois vídeos renderizados no Blender 4.5.3 / Cycles, inspirados no storyboard: carta saindo de um baralho, giro, arco luminoso e enquadramento frontal. Sorte usa verde e dourado; Revés, vermelho e cobre. A geometria, os materiais, as luzes e a animação são editáveis.

Esta entrega contém recursos visuais independentes. A integração no jogo ainda deve ser feita. Nenhum arquivo do projeto Sales Game foi alterado: os 290 arquivos da cópia extraída foram comparados por SHA-256 com o ZIP recebido.

## Arquivos

| Arquivo | Uso |
| --- | --- |
| `SalesGame_Sorte_Reves_Preview.mp4` | Prévia das duas animações lado a lado, 1280 × 800 px. |
| `media/sorte.mp4` e `media/reves.mp4` | Visualização e alternativa com fundo azul-escuro `#07111F`. H.264; sem transparência. |
| `media/sorte.webm` e `media/reves.webm` | Sobreposição ao modal, com transparência. VP9 com canal alfa. |
| `media/sorte-poster.png` e `media/reves-poster.png` | Quadro final transparente: imagem estática, falha de reprodução e movimento reduzido. |
| `SalesGame_Sorte_Reves.blend` | Cena editável com as cenas `Sorte` e `Reves`. Fonte incorporada. |
| `source/build_cards.py` | Reconstrói a cena e renderiza os quadros. |
| `source/encode_videos.py` | Exporta vídeos com FFmpeg e verifica dimensões, duração e quadros. |
| `source/verify_assets.py` | Verifica os vídeos exportados e decodifica o canal alfa. |
| `PROMPT_CODEX.md` | Instruções de integração restrita ao modal existente em React. |
| `manifest.json` | Metadados dos vídeos exportados. |

## Duração e composição

960 × 1200 px, proporção 4:5, 30 fps, 72 quadros, 2,4 segundos, sem áudio. O movimento principal termina no quadro 45, aproximadamente 1,47 s desde o primeiro quadro. A carta permanece de frente até o fim. Não reproduzir em loop.

O vídeo contém somente os rótulos fixos Sorte/Revés e elementos decorativos. **Não contém título do evento, valor, saldo, descrição ou botão de confirmação.** Esses dados precisam vir da carta já selecionada no React. Há efeitos condicionais no baralho; a cor da carta não substitui o cálculo do efeito.

No quadro final, a área sugerida para sobreposição tem coordenadas normalizadas `left: 25.5%; top: 47%; width: 49%; height: 31%`, relativas ao quadro inteiro. É uma região gráfica, não uma altura suficiente garantida para todas as descrições. Nunca corte o texto para fazê-lo caber. Em telas estreitas ou com ampliação de fonte, coloque o conteúdo real em um painel abaixo da animação, mantendo a confirmação visível e o modal rolável.

O fundo transparente aparece preto em alguns visualizadores de arquivos. Os MP4 possuem fundo opaco de propósito. A reprodução de WebM com transparência precisa ser verificada nos navegadores de destino; suporte ao codec não garante a composição correta do alfa. Use o MP4 ou o PNG quando necessário.

## Como usar no projeto

1. Copie apenas `media/` para `public/media/sorte-reves/`.
2. Integre a apresentação em `src/modals/SorteRevesModal.jsx` seguindo `PROMPT_CODEX.md`.
3. Selecione a mídia com o `card.kind` já existente: `SORTE` usa `sorte`; o outro tipo usa `reves`.
4. Mantenha `card.title`, `resolved.text`, a informação sobre confirmação e o botão real no React.
5. O fim ou a falha do vídeo controla apenas a apresentação. A aplicação do efeito continua exclusivamente na confirmação existente.

Um vídeo pré-renderizado pode ser exibido por um componente React usando o elemento nativo de vídeo. **Esta entrega não exige Three.js no navegador.** Se futuramente for necessária uma câmera interativa ou rotação por arraste, isso será uma implementação 3D em tempo real diferente. Não adicione essa dependência para reproduzir estes arquivos.

O MP4 pode ser reproduzido imediatamente para avaliar a animação; ele não é uma gravação do jogo integrado. A criação segue a direção visual da imagem de referência, sem prometer reprodução idêntica de cada detalhe do conceito gerado.

## Editar e renderizar

Abra `SalesGame_Sorte_Reves.blend` no Blender 4.5.3. Use o seletor de cenas para escolher `Sorte` ou `Reves`. O quadro 45 mostra a pose final. Os objetos `Hero`, `Decorative deck` e `Reveal light arc` concentram as animações principais. Os materiais são procedurais; não dependem de texturas externas.

Para reconstruir os arquivos a partir do script, com Blender e FFmpeg instalados:

```sh
blender -b -t 8 --python source/build_cards.py -- --mode render
python source/encode_videos.py
python source/verify_assets.py
```

Execute na pasta deste pacote. Os PNG intermediários são escritos em `../render-frames/`; os vídeos, em `media/`. O script reutiliza quadros já presentes: **apague ou mova a pasta `../render-frames/` antes de renderizar uma cena modificada**, para não misturar versões. Os quadros após 45 repetem a pose de leitura para economizar renderização.

O script foi executado com o módulo `bpy` 4.5.3 e Python 3.11. Também aceita a execução pelo Blender conforme o comando acima. Em sistemas sem DejaVu Sans, a reconstrução pelo script usa a fonte padrão; o `.blend` entregue inclui a fonte usada nesta renderização.

## Limite da verificação

Foram verificados os quadros renderizados, a estrutura dos vídeos, a duração, a ausência de áudio e o canal alfa dos WebM por decodificação. A integração React e a reprodução nos dispositivos do jogo não foram executadas nesta entrega. Valide-as ao integrar, especialmente o fallback, o texto longo, a confirmação única e o modo de movimento reduzido.
