"""Sales Game: independent Blender 4.5 card reveal assets. No game code.

Blender: blender -b -t 8 --python source/build_cards.py -- --mode preview
Python + bpy: python source/build_cards.py --mode preview
Modes: preview / build / render. All scenes use procedural materials.
"""
import bpy
import math
import os
import sys
import argparse
import random
import shutil
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parent.parent
FRAMES = ROOT.parent / 'render-frames'
FPS = 30
END = 72
SIZE = (960, 1200)
FONT_PATH = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'

def material(name, color, metallic=0., rough=.4, emission=0., texture=False):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Metallic'].default_value = metallic
    p.inputs['Roughness'].default_value = rough
    if emission:
        p.inputs['Emission Color'].default_value = (*color, 1)
        p.inputs['Emission Strength'].default_value = emission
    if texture:
        p.inputs['Specular IOR Level'].default_value = .16
        n = m.node_tree.nodes.new('ShaderNodeTexNoise')
        n.inputs['Scale'].default_value = 140
        n.inputs['Detail'].default_value = 2
        b = m.node_tree.nodes.new('ShaderNodeBump')
        b.inputs['Strength'].default_value = .09
        b.inputs['Distance'].default_value = .007
        m.node_tree.links.new(n.outputs['Fac'], b.inputs['Height'])
        m.node_tree.links.new(b.outputs['Normal'], p.inputs['Normal'])
    return m

def mesh(name, vertices, faces, mat, parent=None):
    d = bpy.data.meshes.new(name)
    d.from_pydata(vertices, [], faces)
    d.update()
    o = bpy.data.objects.new(name, d)
    bpy.context.collection.objects.link(o)
    o.data.materials.append(mat)
    if parent: o.parent = parent
    return o

def round_points(w,h,r,n=12):
    pts=[]
    for cx,cy,start in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
        for i in range(n+1):
            a=math.radians(start+90*i/n)
            pts.append((cx+r*math.cos(a),cy+r*math.sin(a)))
    return pts

def plate(name,w,h,r,thickness,z,mat,parent):
    pts=round_points(w,h,r)
    count=len(pts)
    verts=[(x,y,z-thickness/2) for x,y in pts]+[(x,y,z+thickness/2) for x,y in pts]
    faces=[tuple(reversed(range(count))),tuple(range(count,2*count))]
    faces += [(i,(i+1)%count,(i+1)%count+count,i+count) for i in range(count)]
    o=mesh(name,verts,faces,mat,parent)
    b=o.modifiers.new('Soft manufactured edges','BEVEL');b.width=.012;b.segments=3
    o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return o

def line(name, points, mat, radius=.01,parent=None,closed=False):
    c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=1
    c.bevel_depth=radius;c.bevel_resolution=3
    s=c.splines.new('POLY');s.points.add(len(points)-1)
    for p,co in zip(s.points,points): p.co=(*co,1)
    s.use_cyclic_u=closed
    o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o)
    o.data.materials.append(mat)
    if parent:o.parent=parent
    return o

def border(name,w,h,z,mat,parent,radius=.007):
    return line(name,[(x,y,z) for x,y in round_points(w,h,.14)],mat,radius,parent,True)

def shape(name,pts,z,mat,parent,depth=.045):
    n=len(pts)
    v=[(x,y,z) for x,y in pts]+[(x,y,z+depth) for x,y in pts]
    f=[tuple(reversed(range(n))),tuple(range(n,2*n))]
    f += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    o=mesh(name,v,f,mat,parent)
    b=o.modifiers.new('Embossed bevel','BEVEL');b.width=.015;b.segments=3
    o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return o

def emblem(kind,y,z,mat,parent,size=.42):
    if kind=='Sorte':
        pts=[]
        for i in range(8):
            a=math.pi/2+i*math.pi/4
            r=size if i%2==0 else size*.28
            pts.append((r*math.cos(a),y+r*math.sin(a)))
    else:
        pts=[(-.03,.5),(-.3,-.06),(-.06,-.06),(-.18,-.5),(.32,.12),(.06,.12),(.25,.5)]
        pts=[(x*size*2,y+v*size*2) for x,v in pts]
    return shape(kind+' emblem',pts,z,mat,parent)

def text_obj(text,y,z,mat,parent,size=.2):
    d=bpy.data.curves.new(text,'FONT');d.body=text;d.align_x='CENTER';d.align_y='CENTER'
    d.size=size;d.space_character=1.18;d.extrude=.001;d.bevel_depth=.0005
    if os.path.isfile(FONT_PATH): d.font=bpy.data.fonts.load(FONT_PATH,check_existing=True)
    o=bpy.data.objects.new(text,d);bpy.context.collection.objects.link(o)
    o.location=(0,y,z);o.parent=parent;d.materials.append(mat)
    return o

def empty(name):
    o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);return o

def key(o,frame,loc=None,rot=None,scale=None):
    if loc is not None:o.location=loc;o.keyframe_insert('location',frame=frame)
    if rot is not None:o.rotation_euler=rot;o.keyframe_insert('rotation_euler',frame=frame)
    if scale is not None:o.scale=(scale,)*3;o.keyframe_insert('scale',frame=frame)

def area(name,loc,power,color,size,target=(0,0,0)):
    d=bpy.data.lights.new(name,'AREA');d.energy=power;d.color=color;d.shape='DISK';d.size=size
    o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()

def make_card(kind,gold,skin,navy,glow,ivory,name='Hero',full=True):
    p=empty(name)
    plate(name+' metal edge',2.78,4.05,.20,.085,0,gold,p)
    plate(name+' front leather',2.72,3.99,.185,.024,.051,skin,p)
    plate(name+' back leather',2.72,3.99,.185,.024,-.051,navy,p)
    border(name+' outer inlay',2.63,3.9,.068,gold,p,.009)
    border(name+' inner inlay',2.49,3.76,.069,gold,p,.003)
    border(name+' back inlay',2.59,3.87,-.071,gold,p,.008)
    if full:
        border(name+' rim illumination',2.74,4.01,.025,glow,p,.005)
        emblem(kind,1.28,.081,gold,p,size=.28)
        text_obj('SORTE' if kind=='Sorte' else 'REVÉS',.73,.08,ivory,p,.23)
        line('Header separator',[(-.91,.41,.079),(.91,.41,.079)],gold,.004,p)
        line('Footer separator',[(-.65,-1.62,.079),(.65,-1.62,.079)],gold,.003,p)
        # Neutral reverse is intentionally unrelated to the already-selected effect.
        back=empty('Neutral back emblem');back.parent=p;back.rotation_euler=(0,math.pi,0)
        emblem('Sorte',.09,.085,gold,back,size=.4)
        text_obj('SORTE & REVÉS',-.61,.08,gold,back,.115)
        for sx in [-1,1]:
            for sy in [-1,1]:
                pts=[(sx*.94,sy*1.8,.08),(sx*.98,sy*1.62,.08),(sx*1.12,sy*1.58,.08)]
                line('Corner engraving',pts,gold,.006,p)
                shape('Corner diamond',[(sx*1.08-.033,sy*1.74),(sx*1.08,sy*1.74+.05),(sx*1.08+.033,sy*1.74),(sx*1.08,sy*1.74-.05)],.075,gold,p,.008)
    return p

def scene(kind):
    s=bpy.data.scenes.new(kind)
    bpy.context.window.scene=s
    s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=16
    s.cycles.use_denoising=True;s.cycles.max_bounces=4
    s.cycles.diffuse_bounces=2;s.cycles.glossy_bounces=2;s.cycles.transmission_bounces=0
    s.render.threads_mode='FIXED';s.render.threads=8
    s.render.resolution_x,s.render.resolution_y=SIZE;s.render.resolution_percentage=100
    s.render.film_transparent=True;s.render.image_settings.file_format='PNG'
    s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='8'
    s.render.fps=FPS;s.frame_start=1;s.frame_end=END
    s.view_settings.view_transform='AgX'
    s.world=bpy.data.worlds.new(kind+' studio');s.world.use_nodes=True
    s.world.node_tree.nodes.get('Background').inputs[0].default_value=(.13,.17,.24,1)
    s.world.node_tree.nodes.get('Background').inputs[1].default_value=.28
    green=(.008,.068,.033);red=(.09,.006,.012)
    gold=material(kind+' brushed metal',(.74,.48,.15) if kind=='Sorte' else (.73,.32,.29),.83,.25)
    skin=material(kind+' micrograin leather',green if kind=='Sorte' else red,0,.5,texture=True)
    navy=material(kind+' neutral navy',(.006,.011,.022),0,.5,texture=True)
    glow=material(kind+' luminous rim',(.33,.75,.13) if kind=='Sorte' else (1.,.025,.017),.3,.3,2)
    trailmat=material(kind+' trail',(.75,.4,.075) if kind=='Sorte' else (1.,.02,.005),.1,.3,4)
    ivory=material(kind+' letters',(.87,.8,.55) if kind=='Sorte' else (.94,.75,.72),.4,.25)
    root=make_card(kind,gold,skin,navy,glow,ivory)
    poses=[(1,(-.12,-.92,-.45),(1.13,math.pi,-.2),.57),
           (10,(-.19,-.54,-.15),(.85,math.pi+.18,-.13),.66),
           (22,(-.11,.0,.05),(.3,4.40,-.10),.82),
           (36,(.03,.1,.07),(.05,6.05,.035),.98),
           (45,(0,0,0),(0,2*math.pi,0),1),
           (END,(0,0,0),(0,2*math.pi,0),1)]
    for f,l,r,sc in poses:key(root,f,l,r,sc)
    deck=empty('Decorative deck')
    for i in range(6):
        p=make_card(kind,gold,skin,navy,glow,ivory,name='Deck card '+str(i),full=False)
        p.parent=deck;p.location=(.022*i,0,-.075*i)
    for f,sc in [(1,.57),(18,.57),(37,.24),(45,.001),(END,.001)]:
        # Orthographic staging keeps the decorative stack behind the turning card.
        key(deck,f,(-.12,-.99,-4),(1.13,math.pi,-.2),sc)
    arc=empty('Reveal light arc')
    for j in range(2):
        points=[]
        for i in range(90):
            a=-.9+4.4*i/89
            points.append(((1.48+j*.055)*math.cos(a),.35+(.64+j*.025)*math.sin(a),-.4+.24*math.sin(a)))
        line('Metallic orbit '+str(j),points,trailmat,.009 if j==0 else .003,arc)
    for f,sc in [(1,.001),(12,.4),(24,1),(34,1.1),(45,.001),(END,.001)]:key(arc,f,scale=sc,rot=(.0,.0,math.radians(-20+f*1.4)))
    rng=random.Random(72)
    for i in range(20):
        angle=rng.uniform(0,math.tau);rad=rng.uniform(1.25,1.78);sz=rng.uniform(.009,.019)
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=sz)
        o=bpy.context.object;o.name='Light fleck '+str(i);o.data.materials.append(trailmat)
        pos=(math.cos(angle)*rad,math.sin(angle)*rad*.9,-.2)
        key(o,1,loc=pos,scale=.001);key(o,16,loc=pos,scale=.6)
        key(o,31,loc=(pos[0]*1.10,pos[1]*1.1+.18,-.1),scale=1)
        key(o,45,loc=(pos[0]*1.2,pos[1]*1.2+.3,-.3),scale=.001)
    d=bpy.data.cameras.new(kind+' camera');cam=bpy.data.objects.new(kind+' camera',d)
    s.collection.objects.link(cam);cam.location=(0,0,10);cam.rotation_euler=(0,0,0)
    d.type='ORTHO';d.ortho_scale=5.25;s.camera=cam
    area('Large key',(-3,3,5),500,(1.,.86,.65),4)
    area('Soft fill',(3,0,4),260,(.55,.69,1.),3)
    area('Upper rim',(0,4,1),650,(1.,.69,.32) if kind=='Sorte' else (1.,.12,.08),3)
    # The middle of the card deliberately remains blank for the existing React content.
    s['integration_note']='VISUAL ONLY. No title, cash, event, outcome computation or confirmation is baked in.'
    s['react_content_safe_box_normalized']=[.255,.47,.49,.31]
    s['reveal_settled_frame']=45;s['duration_seconds']=END/FPS
    s.frame_set(45)
    return s

def main():
    argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:]
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['build','preview','render'],default='build')
    p.add_argument('--kind',choices=['Sorte','Reves','all'],default='all')
    a=p.parse_args(argv)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scenes=[scene('Sorte'),scene('Reves')]
    for sc in list(bpy.data.scenes):
        if sc not in scenes:bpy.data.scenes.remove(sc)
    bpy.context.window.scene=scenes[0]
    ROOT.mkdir(parents=True,exist_ok=True);(ROOT/'media').mkdir(exist_ok=True)
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'SalesGame_Sorte_Reves.blend'))
    if a.mode=='build':return
    for sc in scenes:
        if a.kind!='all' and sc.name!=a.kind:continue
        bpy.context.window.scene=sc
        out=FRAMES/sc.name.lower();out.mkdir(parents=True,exist_ok=True)
        if a.mode=='preview':
            for f in [1,22,45]:
                sc.frame_set(f);sc.render.filepath=str(out/f'preview_{f:03d}.png')
                bpy.ops.render.render(write_still=True)
        else:
            for f in range(1,END+1):
                target=out/f'{f:04d}.png'
                if target.exists():continue
                if f>45:
                    shutil.copyfile(out/'0045.png',target)
                    continue
                sc.frame_set(f);sc.render.filepath=str(target)
                bpy.ops.render.render(write_still=True)
                print(f'RENDER_PROGRESS {sc.name} {f}/{END}',flush=True)
    print('COMPLETE',flush=True)

if __name__=='__main__':main()
