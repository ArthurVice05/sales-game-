"""Encode Blender frames with FFmpeg. Run after build_cards.py --mode render.

Requires ffmpeg and ffprobe in PATH. No Python packages required.
The opaque MP4 is the preview / compatibility fallback; only WebM has alpha.
"""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent
FRAMES = ROOT.parent / 'render-frames'
MEDIA = ROOT / 'media'

def run(args):
    subprocess.run(args, check=True)

def main():
    MEDIA.mkdir(exist_ok=True)
    manifest = {'fps': 30, 'frames': 72, 'duration_seconds': 2.4,
                'width': 960, 'height': 1200, 'audio': False,
                'settled_frame': 45, 'background_hex': '#07111F', 'files': []}
    for kind in ['sorte', 'reves']:
        folder = FRAMES / kind
        for frame in range(1, 73):
            if not (folder / f'{frame:04d}.png').is_file():
                raise FileNotFoundError(f'Missing {kind} frame {frame}')
        common = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                  '-framerate', '30', '-start_number', '1', '-i', str(folder / '%04d.png')]
        run(common + ['-frames:v', '72', '-an', '-c:v', 'libvpx-vp9',
                      '-pix_fmt', 'yuva420p', '-b:v', '0', '-crf', '24',
                      '-deadline', 'good', '-cpu-used', '4', '-row-mt', '1',
                      '-threads', '4', str(MEDIA / f'{kind}.webm')])
        run(common + ['-f', 'lavfi', '-i', 'color=c=0x07111F:s=960x1200:r=30',
                      '-filter_complex', '[1:v][0:v]overlay=shortest=1:format=auto,format=yuv420p[v]',
                      '-map', '[v]', '-frames:v', '72', '-an', '-c:v', 'libx264',
                      '-crf', '18', '-preset', 'medium', '-threads', '4',
                      '-movflags', '+faststart', str(MEDIA / f'{kind}.mp4')])
        shutil.copyfile(folder / '0045.png', MEDIA / f'{kind}-poster.png')
        for ext in ['webm', 'mp4']:
            path = MEDIA / f'{kind}.{ext}'
            data = json.loads(subprocess.check_output([
                'ffprobe', '-v', 'error', '-count_frames', '-show_streams',
                '-show_format', '-of', 'json', str(path)]))
            video = next(s for s in data['streams'] if s['codec_type'] == 'video')
            assert video['width'] == 960 and video['height'] == 1200
            assert int(video['nb_read_frames']) == 72
            assert abs(float(data['format']['duration']) - 2.4) < .05
            assert len(data['streams']) == 1
            manifest['files'].append({'name': path.name, 'bytes': path.stat().st_size,
                                      'codec': video['codec_name'],
                                      'alpha': ext == 'webm'})
    (ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
         '-i', str(MEDIA / 'sorte.mp4'), '-i', str(MEDIA / 'reves.mp4'),
         '-filter_complex_threads', '2', '-filter_complex',
         '[0:v]scale=640:800[a];[1:v]scale=640:800[b];'
         '[a][b]hstack=inputs=2,drawbox=x=639:y=32:w=2:h=736:color=0x25354A:t=fill[v]',
         '-map', '[v]', '-an', '-c:v', 'libx264', '-crf', '18', '-preset', 'medium',
         '-threads', '4', '-movflags', '+faststart',
         str(ROOT / 'SalesGame_Sorte_Reves_Preview.mp4')])

if __name__ == '__main__':
    main()
