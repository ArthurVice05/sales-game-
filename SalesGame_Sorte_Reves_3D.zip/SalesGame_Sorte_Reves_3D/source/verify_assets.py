"""Check exported duration/frame count and decode the actual WebM alpha plane.

Uses only Python's standard library and FFmpeg/ffprobe.
"""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent.parent

def main():
    results = []
    for kind in ['sorte', 'reves']:
        for ext in ['webm', 'mp4']:
            path = ROOT / 'media' / f'{kind}.{ext}'
            meta = json.loads(subprocess.check_output([
                'ffprobe', '-v', 'error', '-count_frames', '-show_streams',
                '-show_format', '-of', 'json', str(path)]))
            streams = meta['streams']
            assert len(streams) == 1 and streams[0]['codec_type'] == 'video'
            v = streams[0]
            assert (v['width'], v['height']) == (960, 1200)
            assert v['r_frame_rate'] == '30/1' and int(v['nb_read_frames']) == 72
            assert abs(float(meta['format']['duration']) - 2.4) < .05
            item = {'file': path.name, 'frames': 72, 'fps': 30, 'duration_seconds': 2.4,
                    'resolution': [960, 1200], 'audio': False}
            if ext == 'webm':
                alpha = subprocess.check_output([
                    'ffmpeg', '-v', 'error', '-c:v', 'libvpx-vp9', '-i', str(path),
                    '-ss', '1.5', '-vf', 'alphaextract', '-frames:v', '1',
                    '-pix_fmt', 'gray', '-f', 'rawvideo', 'pipe:1'])
                assert len(alpha) == 960 * 1200
                assert min(alpha) == 0 and max(alpha) == 255
                assert alpha[0] == 0 and alpha[600 * 960 + 480] == 255
                item['alpha_verified_by_decoding'] = True
            subprocess.run(['ffmpeg', '-v', 'error', '-xerror', '-i', str(path),
                            '-f', 'null', '-'], check=True)
            results.append(item)
    result = {'export_checks_passed': True, 'files': results,
              'integration_browser_tested': False}
    (ROOT / 'VERIFICACAO.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
